-- Copyright 2016 The Cartographer Authors
--
-- Licensed under the Apache License, Version 2.0 (the "License");
-- you may not use this file except in compliance with the License.
-- You may obtain a copy of the License at
--
--      http://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.

include "map_builder.lua"
include "trajectory_builder.lua"

options = {
  map_builder = MAP_BUILDER,
  trajectory_builder = TRAJECTORY_BUILDER,
  map_frame = "map",
  tracking_frame = "camera_gyro_frame",
  published_frame = "base_link",
  odom_frame = "odom",
  provide_odom_frame = false,
  publish_frame_projected_to_2d = false,
  use_pose_extrapolator = true,
  use_odometry =true,
  use_nav_sat = false,
  use_landmarks = false,
  --普通激光的数据帧
  num_laser_scans = 1,
  --多回波激光的数据帧
  num_multi_echo_laser_scans = 0,
  --for (int i = 0; i != num_subdivisions_per_laser_scan_; ++i)
  --points.points.size() * i / num_subdivisions_per_laser_scan_;
  num_subdivisions_per_laser_scan = 10,
  num_point_clouds = 1,
  lookup_transform_timeout_sec = 0.02,
  submap_publish_period_sec = 0.3,
  pose_publish_period_sec = 5e-3,
  trajectory_publish_period_sec = 30e-3,
  rangefinder_sampling_ratio = 1,
  odometry_sampling_ratio = 1,
  fixed_frame_pose_sampling_ratio = 1.,
  imu_sampling_ratio = 1,
  landmarks_sampling_ratio = 1.,
}

MAP_BUILDER.use_trajectory_builder_3d = true
MAP_BUILDER.num_background_threads = 7
POSE_GRAPH.optimization_problem.huber_scale = 5e2
POSE_GRAPH.optimize_every_n_nodes = 320
POSE_GRAPH.constraint_builder.sampling_ratio = 0.005
POSE_GRAPH.optimization_problem.ceres_solver_options.max_num_iterations = 10
POSE_GRAPH.constraint_builder.min_score = 0.62
POSE_GRAPH.constraint_builder.global_localization_min_score = 0.66



-- -- 其中有个程序中imu_gravity_time_constant又去算低通滤波的系数 alpha = 1. - std::exp(-delta_t / imu_gravity_time_constant_);
-- MAP_BUILDER.use_trajectory_builder_3d = true
-- MAP_BUILDER.num_background_threads = 4

-- --选择点云的范围
TRAJECTORY_BUILDER_3D.min_range = 0.2
TRAJECTORY_BUILDER_3D.max_range = 16
--设置体素滤波的大小（就是多大一个立方体为一个点云）
TRAJECTORY_BUILDER_3D.voxel_filter_size = 0.001
--就是说多个扫描组装成一个扫描提供给cart，
 TRAJECTORY_BUILDER_3D.num_accumulated_range_data = 10

-- --high_resolution
-- --low_resolution
-- --
-- TRAJECTORY_BUILDER_3D.low_resolution_adaptive_voxel_filter.max_range = 4
-- TRAJECTORY_BUILDER_3D.low_resolution_adaptive_voxel_filter.min_num_points = 500
-- TRAJECTORY_BUILDER_3D.high_resolution_adaptive_voxel_filter.max_range = 8
-- TRAJECTORY_BUILDER_3D.high_resolution_adaptive_voxel_filter.min_num_points = 400


--occupied_space_weight是点云的信任度
--rotation_weight和translation_weigh是IMU和里程计的信任度
--occupied_space_weight_0  high resolution
--occupied_space_weight_1  low resolution
TRAJECTORY_BUILDER_3D.ceres_scan_matcher.occupied_space_weight_0 = 20
TRAJECTORY_BUILDER_3D.ceres_scan_matcher.occupied_space_weight_1 = 10
TRAJECTORY_BUILDER_3D.ceres_scan_matcher.translation_weight = 200.
TRAJECTORY_BUILDER_3D.ceres_scan_matcher.rotation_weight = 500
--TRAJECTORY_BUILDER_3D.ceres_scan_matcher.only_optimize_yaw = true

-- --设置ceres 看参数名字
-- --TRAJECTORY_BUILDER_3D.ceres_scan_matcher.ceres_solver_options.use_nonmonotonic_steps = false.
-- --TRAJECTORY_BUILDER_3D.ceres_scan_matcher.ceres_solver_options.max_num_iterations = 12.
-- --TRAJECTORY_BUILDER_3D.ceres_scan_matcher.ceres_solver_options.num_threads = 1.

--还不知道
  TRAJECTORY_BUILDER_3D.use_online_correlative_scan_matching = true
--  TRAJECTORY_BUILDER_3D.real_time_correlative_scan_matcher.linear_search_window = 7
--  TRAJECTORY_BUILDER_3D.real_time_correlative_scan_matcher.angular_search_window=math.rad(30)
--  TRAJECTORY_BUILDER_3D.real_time_correlative_scan_matcher.translation_delta_cost_weight = 1e-1
--  TRAJECTORY_BUILDER_3D.real_time_correlative_scan_matcher.rotation_delta_cost_weight= 1e-1


-- --当motion 在下面参数确定的阔直的时候就把一个匹配插入submap，还有没有
-- --提供无效信息的匹配dropped
-- --用默认，
TRAJECTORY_BUILDER_3D.motion_filter.max_distance_meters = 0.1
TRAJECTORY_BUILDER_3D.motion_filter.max_time_seconds = 2.25
TRAJECTORY_BUILDER_3D.motion_filter.max_angle_radians = math.rad(1)
-- --建图用的
TRAJECTORY_BUILDER_3D.submaps.high_resolution = 0.10
TRAJECTORY_BUILDER_3D.submaps.low_resolution = 0.5
TRAJECTORY_BUILDER_3D.submaps.high_resolution_max_range = 20
-- --这个submap的大小
-- --大了全局速度快，小了局部漂移影响小
-- TRAJECTORY_BUILDER_3D.submaps.num_range_data = 40

-- -- TRAJECTORY_BUILDER_2D.submaps.grid_options_2d.grid_type
-- -- TRAJECTORY_BUILDER_2D.submaps.range_data_inserter.probability_grid_range_data_inserter.hit_probability
-- -- TRAJECTORY_BUILDER_2D.submaps.range_data_inserter.probability_grid_range_data_inserter.miss_probability
-- -- TRAJECTORY_BUILDER_3D.submaps.range_data_inserter.hit_probability
-- -- TRAJECTORY_BUILDER_3D.submaps.range_data_inserter.miss_probability
-- --
-- --
-- --
-- --全局优化参数
-- --就说一些异常的点通过 Huberloss来配置，huber_scale越大异常直的音响越大
-- --POSE_GRAPH.optimization_problem.huber_scale = 3e2

-- --先关闭globalslam 来调参数，官网这么说的optimize_every_n_nodes = 0
-- POSE_GRAPH.optimize_every_n_nodes = 150
-- --全局约束
-- --搜寻一个新的sbmap和先前一个由下面参数决定的空间区域内的很好匹配的对应submap构建一个约束
-- POSE_GRAPH.constraint_builder.max_constraint_distance = 4
-- POSE_GRAPH.constraint_builder.fast_correlative_scan_matcher.linear_search_window = 7
-- POSE_GRAPH.constraint_builder.fast_correlative_scan_matcher_3d.linear_xy_search_window = 7
-- POSE_GRAPH.constraint_builder.fast_correlative_scan_matcher_3d.linear_z_search_window = 7
-- POSE_GRAPH.constraint_builder.fast_correlative_scan_matcher_3d.angular_search_window =math.rad(30)
-- --限制约束数量
-- POSE_GRAPH.constraint_builder.sampling_ratio = 0.03

-- --FastCorrelativeScanMatcher有很好的率选之后匹配分数大于min_score的时候就送入 Ceres Scan Matcher来优化pose
-- POSE_GRAPH.constraint_builder.min_score = 0.88
-- --POSE_GRAPH.constraint_builder.log_matches = true
-- -- POSE_GRAPH.constraint_builder.ceres_scan_matcher_3d
-- -- POSE_GRAPH.constraint_builder.ceres_scan_matcher
-- POSE_GRAPH.constraint_builder.ceres_scan_matcher_3d.only_optimize_yaw = true

-- --这个都是全剧优化的时候，计算多个Residuals（多个传感器）加权成本函数的一些权重设置
--  POSE_GRAPH.constraint_builder.loop_closure_translation_weight = 500
--  POSE_GRAPH.constraint_builder.loop_closure_rotation_weight = 500
--  POSE_GRAPH.matcher_translation_weight = 1e1
--  POSE_GRAPH.matcher_rotation_weight = 1.6e1
-- --  POSE_GRAPH.optimization_problem.ceres_solver_options
-- --用了Odometry可调的参数
-- --就是说局部的信任直和odom的信任直
-- POSE_GRAPH.optimization_problem.local_slam_pose_translation_weight=1e3
-- POSE_GRAPH.optimization_problem.local_slam_pose_rotation_weight= 1e3
-- POSE_GRAPH.optimization_problem.odometry_translation_weight = 1e5
-- POSE_GRAPH.optimization_problem.odometry_rotation_weight = 1e5
-- POSE_GRAPH.optimization_problem.huber_scale = 5e2
-- POSE_GRAPH.optimization_problem.acceleration_weight = 1e-1
-- POSE_GRAPH.optimization_problem.rotation_weight = 1e1

-- POSE_GRAPH.optimization_problem.ceres_solver_options.max_num_iterations = 10
-- POSE_GRAPH.constraint_builder.global_localization_min_score = 0.86


-- --当node和子图构建约束的时候，扫描将首先送入FastCorrelativeScanMatcher
-- -- Branch and bound机制
-- --POSE_GRAPH.constraint_builder.fast_correlative_scan_matcher_3d.min_rotational_score = 0.
-- --POSE_GRAPH.constraint_builder.fast_correlative_scan_matcher_3d.linear_xy_search_window = 2.

-- --这个是在优化的时候cere提供的一个灵活的imu优化
-- --默认是可以优化外部的标定
-- --如果外部标定不好可使用cere优化，如果标定的好文档说保持默认，
-- --POSE_GRAPH.optimization_problem.log_solver_summary
-- --POSE_GRAPH.optimization_problem.use_online_imu_extrinsics_in_3d


-- --当轨迹完成，就运行一个薪的全局优化名，不需要时实，max_num_final_iterations大一点
-- --POSE_GRAPH.max_num_final_iterations

-- -- POSE_GRAPH.global_sampling_ratio = 0.001


return options